package com.roni2024.ronisfirstappplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class NoamActivity2 extends AppCompatActivity {
    TextView tv1;
    ImageView iv;
    Button bL, bL2, btnGuessNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noam2);
        initViews();
    }

    private void initViews() {
        // חיבור כפתור ל-GameActivity3
        bL = findViewById(R.id.btnLinear);
        bL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // התחברות לפעילות GameActivity3
                Intent intent = new Intent(NoamActivity2.this, GameActivity3.class);
                startActivity(intent);
            }
        });

        // חיבור כפתור ל-MainActivity
        bL2 = findViewById(R.id.btnLinear2);
        bL2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // התחברות לפעילות MainActivity
                Intent intent = new Intent(NoamActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // חיבור כפתור לפעילות GuessNumberActivity (למשל)
        btnGuessNum = findViewById(R.id.gotoGuessNum);
        btnGuessNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {Intent intent = new Intent(NoamActivity2.this, GameActivity3.class);
                startActivityForResult(intent,1111);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1111)
            if (resultCode==RESULT_OK) {
                int counter = data.getIntExtra("num_guesses", 0);
                Toast.makeText(this, ""+counter, Toast.LENGTH_SHORT).show();
            }

    }
}

